#!/bin/bash
cd "$(dirname "$0")"
echo "========================================="
echo "CustomRAG - Installation für macOS"
echo "========================================="
echo "Installiere Abhängigkeiten via Homebrew (falls nötig)..."
brew install pygobject3 gtk+3 2>/dev/null || echo "Homebrew nicht gefunden. Bitte installiere GTK3 manuell."
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
echo "Starte CustomRAG..."
python3 gui_custom_collector.py
