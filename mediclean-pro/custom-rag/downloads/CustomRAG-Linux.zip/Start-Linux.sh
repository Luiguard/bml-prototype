#!/bin/bash
cd "$(dirname "$0")"
echo "========================================="
echo "CustomRAG - Installation für Linux"
echo "========================================="
echo "Prüfe System-Abhängigkeiten..."
sudo apt-get update && sudo apt-get install -y python3-gi python3-gi-cairo gir1.2-gtk-3.0
if [ ! -d ".venv" ]; then
    python3 -m venv --system-site-packages .venv
fi
.venv/bin/pip install -r requirements.txt
echo "Starte Custom RAG..."
.venv/bin/python gui_custom_collector.py
