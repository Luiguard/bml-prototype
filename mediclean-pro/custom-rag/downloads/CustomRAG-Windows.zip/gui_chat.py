"""GTK-Chat – lokaler Assistent ohne Terminal."""
from __future__ import annotations

import os
import sys
import threading
from pathlib import Path

_BASE = Path(__file__).resolve().parent
if str(_BASE) not in sys.path:
    sys.path.insert(0, str(_BASE))

from rag_core.gui_resources import child_env

_env = child_env()
for _k, _v in _env.items():
    if _k.startswith(("OMP_", "MKL_", "NUMEXPR_", "OPENBLAS_", "VECLIB_", "TOKENIZERS")):
        os.environ[_k] = _v

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, Gdk, Pango

from rag_core.assistant import LocalAssistant
from rag_core.embeddings import embed_query
from rag_core.ollama import resolve_model
from rag_core.prompts import MODE_AUDIT, MODE_CODE, MODE_REVIEW, MODE_SUPPORT
from rag_core.retrieval import KnowledgeRetriever

MODE_LABELS = {
    "auto": "Automatisch",
    MODE_SUPPORT: "Support",
    MODE_CODE: "Code",
    MODE_REVIEW: "Review",
    MODE_AUDIT: "Audit",
}


class RAGChatWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Lokale IT-KI – Assistent")
        self.set_default_size(720, 560)
        self.set_border_width(12)
        self._busy = False
        self._assistant: LocalAssistant | None = None
        self._retriever: KnowledgeRetriever | None = None
        
        self._attached_context = ""
        self._attached_name = ""

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.add(vbox)

        self.status_label = Gtk.Label(label="Initialisiere…")
        self.status_label.set_halign(Gtk.Align.START)
        vbox.pack_start(self.status_label, False, False, 0)

        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scroll.set_vexpand(True)
        self.chat_view = Gtk.TextView()
        self.chat_view.set_editable(False)
        self.chat_view.set_wrap_mode(Gtk.WrapMode.WORD)
        # Styling wird nun über CSS (rag_core/gui_theme) geregelt
        scroll.add(self.chat_view)
        vbox.pack_start(scroll, True, True, 0)
        self._buf = self.chat_view.get_buffer()
        self._append("System", "Willkommen. Stelle eine Frage oder wähle einen Modus.\n")

        bar_models = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        vbox.pack_start(bar_models, False, False, 0)

        self.db_combo = Gtk.ComboBoxText()
        db_dir = _BASE / "lancedb_index"
        has_dbs = False
        if db_dir.exists():
            for d in db_dir.glob("*.lance"):
                if d.is_dir():
                    self.db_combo.append(d.stem, f"DB: {d.stem}")
                    has_dbs = True
        if not has_dbs:
            self.db_combo.append("it_prime", "DB: it_prime")
        self.db_combo.set_active(0)
        self.db_combo.connect("changed", self._on_db_changed)
        bar_models.pack_start(self.db_combo, False, False, 0)

        self.model_combo = Gtk.ComboBoxText()
        self.model_combo.set_tooltip_text("KI-Modell auswählen")
        
        try:
            from rag_core.ollama import list_models
            available_models = list_models()
        except:
            available_models = []
            
        recommended = {
            "llama3.2:1b": "llama3.2:1b (Laptop / sehr schnell)",
            "llama3.2:3b": "llama3.2:3b (Standard / gute Balance)",
            "qwen2.5-coder:7b": "qwen2.5-coder:7b (Code / guter PC)",
            "mistral:7b": "mistral:7b (Allrounder / guter PC)",
            "qwen2.5-coder:14b": "qwen2.5-coder:14b (Stark / Mac M-Serie)",
            "mixtral:8x7b": "mixtral:8x7b (Experte / Workstation)",
            "qwen2.5-coder:32b": "qwen2.5-coder:32b (Mastermind / High-End 24GB+ RAM)"
        }
        
        for m in available_models:
            label = recommended.get(m, m)
            self.model_combo.append(m, f"✅ {label}")
            
        for m, label in recommended.items():
            if m not in available_models:
                self.model_combo.append(m, f"📥 {label}")
                
        if available_models:
            self.model_combo.set_active_id(available_models[0])
        else:
            self.model_combo.set_active(0)
            
        bar_models.pack_start(self.model_combo, True, True, 0)

        self.mode_combo = Gtk.ComboBoxText()
        for key, label in MODE_LABELS.items():
            self.mode_combo.append(key, label)
        self.mode_combo.set_active(0)
        self.mode_combo.set_tooltip_text("Antwort-Stil")
        bar_models.pack_start(self.mode_combo, False, False, 0)

        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        vbox.pack_start(bar, False, False, 0)

        self.btn_attach = Gtk.Button(label="📎")
        self.btn_attach.set_tooltip_text("Datei an den Chat anhängen")
        self.btn_attach.connect("clicked", self._on_attach_clicked)
        bar.pack_start(self.btn_attach, False, False, 0)

        self.entry = Gtk.Entry()
        self.entry.set_placeholder_text("Frage eingeben… (/code, /review, /audit möglich)")
        self.entry.connect("activate", self._on_send)
        bar.pack_start(self.entry, True, True, 0)

        self.btn_send = Gtk.Button(label="Senden")
        self.btn_send.get_style_context().add_class("suggested-action")
        self.btn_send.connect("clicked", self._on_send)
        bar.pack_start(self.btn_send, False, False, 0)

        threading.Thread(target=self._init_worker, daemon=True).start()

    def _append(self, who: str, text: str) -> None:
        end = self._buf.get_end_iter()
        self._buf.insert(end, f"\n[{who}]\n{text}\n")

    def _append_stream(self, text: str) -> None:
        end = self._buf.get_end_iter()
        self._buf.insert(end, text)

    def _on_db_changed(self, combo):
        if self._busy: return
        db_name = combo.get_active_id()
        if db_name:
            self.status_label.set_text(f"Lade Datenbank {db_name}…")
            threading.Thread(target=self._init_worker, args=(db_name,), daemon=True).start()

    def _init_worker(self, table_name=None):
        try:
            if not table_name and self.db_combo.get_active_id():
                table_name = self.db_combo.get_active_id()
            r = KnowledgeRetriever(table_name=table_name)
            a = LocalAssistant(r)
            rows = r.row_count() if r.ready else 0
            model = resolve_model() or "nicht verbunden"
            status = (
                f"Wissen: {rows:,} Chunks ({r.table_name}) | Ollama: {model}"
                if r.ready
                else f"⚠️ Keine Daten in {r.table_name} – lade Dokumente in der Collector-GUI!"
            )
            GLib.idle_add(self._on_ready, a, status)
        except Exception as e:
            GLib.idle_add(self._on_ready, None, f"Fehler: {e}")

    def _on_ready(self, assistant: LocalAssistant | None, status: str):
        self._assistant = assistant
        if assistant:
            self._retriever = assistant.retriever
        self.status_label.set_text(status)
        return False

    def _on_attach_clicked(self, widget):
        if self._attached_context:
            self._attached_context = ""
            self._attached_name = ""
            self.btn_attach.get_style_context().remove_class("suggested-action")
            self.btn_attach.set_tooltip_text("Datei an den Chat anhängen")
            self._append("System", "📎 Anhang entfernt.")
            return

        dialog = Gtk.FileChooserDialog(
            title="Datei anhängen",
            parent=self,
            action=Gtk.FileChooserAction.OPEN,
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN, Gtk.ResponseType.OK
        )
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            path = dialog.get_filename()
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    self._attached_context = f.read()
                self._attached_name = os.path.basename(path)
                self.btn_attach.get_style_context().add_class("suggested-action")
                self.btn_attach.set_tooltip_text(f"Angehängt: {self._attached_name} (Klicken zum Entfernen)")
                self._append("System", f"📎 Angehängt: {self._attached_name}")
            except Exception as e:
                self._append("System", f"❌ Fehler beim Lesen der Datei: {e}")
        dialog.destroy()

    def _on_send(self, *_args):
        if self._busy or not self._assistant:
            return
        text = self.entry.get_text().strip()
        if not text:
            return
        self.entry.set_text("")
        self._busy = True
        self.btn_send.set_sensitive(False)
        self._append("Du", text)
        threading.Thread(target=self._answer_worker, args=(text,), daemon=True).start()

    def _selected_mode(self) -> str | None:
        key = self.mode_combo.get_active_id()
        if key == "auto" or not key:
            return None
        return key

    def _answer_worker(self, query: str):
        mode = self._selected_mode()
        
        raw_model_id = self.model_combo.get_active_id()
        model_id = raw_model_id
        if not model_id:
            # Fallback if combo acts weird
            text = self.model_combo.get_active_text()
            model_id = text.replace("✅ ", "").replace("📥 ", "").split(" (")[0]
            
        try:
            from rag_core.ollama import list_models, pull_model
            if model_id not in list_models():
                GLib.idle_add(self._append, "System", f"⬇️ Lade KI-Modell '{model_id}' über Ollama herunter... (Das kann je nach Internetverbindung und Modellgröße einige Zeit in Anspruch nehmen).")
                pull_model(model_id)
                GLib.idle_add(self._append, "System", f"✅ Modell '{model_id}' erfolgreich heruntergeladen!")
        except Exception as e:
            GLib.idle_add(self._append, "System", f"❌ Fehler beim Modell-Download: {e}")
            GLib.idle_add(self._done_answering)
            return

        hits_summary = ""
        try:
            _, mobile = embed_query(query)
            q, parsed_mode = self._assistant.parse_mode(query)
            use_mode = mode or parsed_mode
            hits = self._retriever.search(q)
            hits_summary = self._retriever.format_hit_summary(hits, mobile=mobile)
            GLib.idle_add(self._append, "Quellen", hits_summary or "(keine)")

            GLib.idle_add(self._append, "KI", "")

            def on_token(chunk: str) -> None:
                GLib.idle_add(self._append_stream, chunk)

            context_to_send = f"[Datei: {self._attached_name}]\n{self._attached_context}" if self._attached_context else ""

            result = self._assistant.answer_text(
                q, mode=use_mode, model=model_id, user_context=context_to_send, on_token=on_token, retry_on_unsafe=True
            )
            if result.get("blocked"):
                GLib.idle_add(self._append, "System", result["text"])
            elif not result.get("model") and result.get("text"):
                pass  # already streamed as context
        except Exception as e:
            GLib.idle_add(self._append, "Fehler", str(e))
        finally:
            GLib.idle_add(self._done_answering)

    def _done_answering(self):
        self._busy = False
        self.btn_send.set_sensitive(True)
        return False


if __name__ == "__main__":
    from rag_core.gui_theme import apply_theme
    apply_theme()
    win = RAGChatWindow()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()
