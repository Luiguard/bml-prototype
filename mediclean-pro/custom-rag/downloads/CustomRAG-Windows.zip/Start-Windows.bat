@echo off
echo =========================================
echo CustomRAG - Installation für Windows
echo =========================================
echo.
echo Bitte stelle sicher, dass Python 3.10+ und GTK3 für Windows installiert sind.
echo Empfohlen: MSYS2 verwenden (pacman -S mingw-w64-x86_64-gtk3 mingw-w64-x86_64-python-gobject)
echo.
pause
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt
echo Starte CustomRAG...
.venv\Scripts\python gui_custom_collector.py
pause
