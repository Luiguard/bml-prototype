import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk

def apply_theme():
    css = b"""
    window {
        background-color: #1e1e2e;
    }
    label {
        color: #cdd6f4;
        font-size: 11pt;
    }
    button {
        background-color: #313244;
        color: #cdd6f4;
        border: 1px solid #45475a;
        border-radius: 8px;
        padding: 8px 16px;
        font-weight: bold;
        transition: all 200ms ease;
    }
    button:hover {
        background-color: #45475a;
        border-color: #585b70;
    }
    button.suggested-action {
        background-color: #89b4fa;
        color: #11111b;
        border-color: #b4befe;
    }
    button.suggested-action:hover {
        background-color: #b4befe;
    }
    button.destructive-action {
        background-color: #f38ba8;
        color: #11111b;
        border-color: #eba0ac;
    }
    button.destructive-action:hover {
        background-color: #eba0ac;
    }
    entry {
        background-color: #181825;
        color: #cdd6f4;
        border: 1px solid #45475a;
        border-radius: 8px;
        padding: 8px;
    }
    entry:focus {
        border-color: #89b4fa;
    }
    textview text {
        background-color: #11111b;
        color: #a6adc8;
        font-family: monospace;
        font-size: 11pt;
    }
    combobox {
        background-color: #313244;
        color: #cdd6f4;
        border-radius: 6px;
    }
    scrollbar slider {
        background-color: #45475a;
        border-radius: 4px;
    }
    scrollbar slider:hover {
        background-color: #585b70;
    }
    """
    provider = Gtk.CssProvider()
    provider.load_from_data(css)
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(),
        provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )
