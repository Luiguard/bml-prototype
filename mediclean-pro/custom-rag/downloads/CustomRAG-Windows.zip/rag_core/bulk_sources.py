"""Definition aller Bulk-Wissensquellen (Git, Archive.org, rsync)."""

# Git-Repositories (shallow clone, --depth 1)
GIT_SOURCES = [
    {
        "id": "arch-wiki",
        "name": "Arch Wiki",
        "url": "https://github.com/archlinux/archwiki.git",
        "subdir": "arch-wiki",
        "marker": "README.md",
    },
    {
        "id": "kubernetes-docs",
        "name": "Kubernetes Docs",
        "url": "https://github.com/kubernetes/website.git",
        "subdir": "official-docs/kubernetes",
        "marker": "content",
    },
    {
        "id": "python-docs",
        "name": "Python Dokumentation",
        "url": "https://github.com/python/cpython.git",
        "subdir": "official-docs/python",
        "marker": "Doc",
        "sparse": "Doc",
    },
    {
        "id": "rust-reference",
        "name": "Rust Reference",
        "url": "https://github.com/rust-lang/reference.git",
        "subdir": "official-docs/rust",
        "marker": "src",
    },
    {
        "id": "go-doc",
        "name": "Go Dokumentation",
        "url": "https://github.com/golang/go.git",
        "subdir": "official-docs/go",
        "marker": "doc",
        "sparse": "doc",
    },
    {
        "id": "nginx-docs",
        "name": "Nginx Docs",
        "url": "https://github.com/nginx/documentation.git",
        "subdir": "official-docs/nginx",
        "marker": "content",
    },
    {
        "id": "redis-docs",
        "name": "Redis Docs",
        "url": "https://github.com/redis/redis-doc.git",
        "subdir": "official-docs/redis",
        "marker": "commands",
    },
    {
        "id": "postgres-docs",
        "name": "PostgreSQL Docs",
        "url": "https://github.com/postgres/postgres.git",
        "subdir": "official-docs/postgresql",
        "marker": "doc",
        "sparse": "doc",
    },
    {
        "id": "docker-docs",
        "name": "Docker Docs",
        "url": "https://github.com/docker/docs.git",
        "subdir": "official-docs/docker",
        "marker": "content",
    },
    {
        "id": "terraform-docs",
        "name": "Terraform Docs",
        "url": "https://github.com/hashicorp/terraform.git",
        "subdir": "official-docs/terraform",
        "marker": "website",
        "sparse": "website/docs",
    },
    {
        "id": "owasp-cheatsheets",
        "name": "OWASP Cheat Sheets",
        "url": "https://github.com/OWASP/CheatSheetSeries.git",
        "subdir": "owasp/CheatSheetSeries",
        "marker": "cheatsheets",
    },
    {
        "id": "owasp-asvs",
        "name": "OWASP ASVS",
        "url": "https://github.com/OWASP/ASVS.git",
        "subdir": "owasp/ASVS",
        "marker": "4.0",
    },
    {
        "id": "owasp-wstg",
        "name": "OWASP WSTG",
        "url": "https://github.com/OWASP/wstg.git",
        "subdir": "owasp/wstg",
        "marker": "document",
    },
    {
        "id": "freebsd-doc",
        "name": "FreeBSD Handbook",
        "url": "https://github.com/freebsd/freebsd-doc.git",
        "subdir": "official-docs/freebsd",
        "marker": "documentation",
    },
    {
        "id": "ansible-docs",
        "name": "Ansible Docs",
        "url": "https://github.com/ansible/ansible-documentation.git",
        "subdir": "official-docs/ansible",
        "marker": "docs",
    },
    {
        "id": "git-scm-docs",
        "name": "Git SCM Book",
        "url": "https://github.com/git/git-scm.com.git",
        "subdir": "official-docs/git",
        "marker": "content",
    },
]

# Stack Exchange Archive.org (7z → XML Posts)
# https://archive.org/details/stackexchange
STACKEXCHANGE_DUMPS = [
    {
        "name": "Stack Overflow",
        "site": "stackoverflow.com",
        "file": "stackoverflow.com-Posts.7z",
        "url": "https://archive.org/download/stackexchange/stackoverflow.com-Posts.7z",
        "size": "~15 GB",
    },
    {
        "name": "Server Fault",
        "site": "serverfault.com",
        "file": "serverfault.com.7z",
        "url": "https://archive.org/download/stackexchange/serverfault.com.7z",
        "size": "~1 GB",
    },
    {
        "name": "Super User",
        "site": "superuser.com",
        "file": "superuser.com.7z",
        "url": "https://archive.org/download/stackexchange/superuser.com.7z",
        "size": "~2 GB",
    },
    {
        "name": "Security SE",
        "site": "security.stackexchange.com",
        "file": "security.stackexchange.com.7z",
        "url": "https://archive.org/download/stackexchange/security.stackexchange.com.7z",
        "size": "~500 MB",
    },
    {
        "name": "Ask Ubuntu",
        "site": "askubuntu.com",
        "file": "askubuntu.com.7z",
        "url": "https://archive.org/download/stackexchange/askubuntu.com.7z",
        "size": "~1.5 GB",
    },
    {
        "name": "Unix SE",
        "site": "unix.stackexchange.com",
        "file": "unix.stackexchange.com.7z",
        "url": "https://archive.org/download/stackexchange/unix.stackexchange.com.7z",
        "size": "~1 GB",
    },
    {
        "name": "Software Engineering SE",
        "site": "softwareengineering.stackexchange.com",
        "file": "softwareengineering.stackexchange.com.7z",
        "url": "https://archive.org/download/stackexchange/softwareengineering.stackexchange.com.7z",
        "size": "~400 MB",
    },
]

# IETF Internet-Drafts (zusätzlich zu RFCs)
IETF_DRAFTS_URL = "https://www.ietf.org/archive/id/draft-"
IETF_DRAFTS_INDEX = "https://www.ietf.org/archive/id/"
