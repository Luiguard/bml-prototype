"""Ressourcen-Limits für GUI und Hintergrund-Jobs (Kerne frei lassen)."""
from __future__ import annotations

import os
import shutil
from typing import Sequence

CPU_COUNT = os.cpu_count() or 4
# Mindestens 2 Kerne für Desktop / System frei (anpassbar: RAG_RESERVE_CORES=3)
RESERVE_CORES = max(1, min(CPU_COUNT - 1, int(os.environ.get("RAG_RESERVE_CORES", "2"))))
WORKER_THREADS = max(1, CPU_COUNT - RESERVE_CORES)
NUM_THREADS = str(WORKER_THREADS)

# Max. gleichzeitige schwere Hintergrund-Tasks (Git, rsync, Gutenberg, …)
MAX_BG_TASKS = max(1, int(os.environ.get("RAG_MAX_BG_TASKS", "2")))

# Parallele Wikimedia-wget (1 = schonender)
MAX_WIKI_DOWNLOADS = max(1, int(os.environ.get("RAG_MAX_WIKI_DL", "1")))


def child_env(extra: dict | None = None) -> dict:
    env = os.environ.copy()
    for key in (
        "OMP_NUM_THREADS",
        "MKL_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
    ):
        env[key] = NUM_THREADS
    env["TOKENIZERS_PARALLELISM"] = "false"
    if extra:
        env.update(extra)
    return env


def low_priority_cmd(cmd: Sequence[str]) -> list[str]:
    """nice + ionice (idle) damit der PC reaktionsfähig bleibt."""
    base = ["nice", "-n", "19"]
    if shutil.which("ionice"):
        base.extend(["ionice", "-c", "3"])
    return base + list(cmd)


def resource_summary() -> str:
    return (
        f"CPUs: {CPU_COUNT} gesamt | {RESERVE_CORES} reserviert fürs System | "
        f"Jobs nutzen max. {WORKER_THREADS} Threads, {MAX_BG_TASKS} schwere Tasks parallel"
    )
