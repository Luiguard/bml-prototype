"""Qualitätsfilter und Quellen-Priorisierung für IT-Wissen."""
from pathlib import Path

# Quellen mit niedriger IT-Relevanz (Retrieval + Indexierung)
BLOCKED_SOURCE_FRAGMENTS = (
    "datenschutz",
    "datenpanne",
    "vorratsdatenspeicherung",
    "gesundheitsdaten",
    "personenbezogen",
    "kirchlicher datenschutz",
    "sozialdatenschutz",
)

# Höhere Werte = bevorzugt bei gleicher Ähnlichkeit
SOURCE_BOOST = (
    ("user:", 1.22),
    ("/projects/", 1.20),
    ("stackexchange:", 1.17),
    ("owasp", 1.16),
    ("manpages", 1.18),
    ("stackoverflow", 1.15),
    ("rfcs", 1.14),
    ("arch-wiki", 1.13),
    ("official-docs", 1.12),
    ("tldr-pages", 1.12),
    ("mdn-web-docs/files", 1.10),
    ("linux-docs", 1.10),
    ("gutenberg", 0.85),
    ("wikipedia", 1.0),
    ("processed", 1.02),
)

IT_CONTENT_SIGNALS = (
    "programm", "software", "computer", "algorithmus", "algorithm",
    "netzwerk", "network", "linux", "python", "javascript", "java",
    "api", "server", "datenbank", "database", "compiler", "code",
    "docker", "kubernetes", "git", "http", "tcp", "sql", "nginx",
    "betriebssystem", "kernel", "encryption", "kryptograph",
)


def is_blocked_source(source: str) -> bool:
    s = source.lower()
    return any(b in s for b in BLOCKED_SOURCE_FRAGMENTS)


def source_boost(source: str) -> float:
    s = source.lower()
    if is_blocked_source(s):
        return 0.0
    for pattern, boost in SOURCE_BOOST:
        if pattern in s:
            return boost
    return 0.95


def classify_source(path: str | Path) -> str:
    p = str(path).lower()
    if "manpages" in p:
        return "manpages"
    if "stackoverflow" in p:
        return "stackoverflow"
    if "rfcs" in p:
        return "rfcs"
    if "tldr" in p:
        return "tldr"
    if "stackexchange" in p:
        return "stackexchange"
    if "owasp" in p:
        return "owasp"
    if "arch-wiki" in p:
        return "archwiki"
    if "official-docs" in p:
        return "official-docs"
    if "mdn-web-docs" in p:
        return "mdn"
    if "linux-docs" in p:
        return "linux"
    if "wikipedia" in p or "processed" in p and "wiki" in p:
        return "wikipedia"
    if "gutenberg" in p:
        return "gutenberg"
    return "other"


def is_user_project_source(source: str | Path) -> bool:
    return str(source).startswith("user:") or "/projects/" in str(source).replace("\\", "/")


def is_indexable_content(text: str, source: str | Path) -> bool:
    if len(text.strip()) < 80:
        return False
    src = str(source)
    if is_blocked_source(src):
        return False
    if is_user_project_source(src):
        return True  # eigener Code immer indexieren
    cat = classify_source(src)
    if cat == "wikipedia":
        sample = text[:2500].lower()
        if not any(sig in sample for sig in IT_CONTENT_SIGNALS):
            return False
    if cat == "gutenberg":
        sample = text[:1500].lower()
        if not any(sig in sample for sig in IT_CONTENT_SIGNALS):
            return False
    return True


def is_low_quality_hit(hit: dict) -> bool:
    src = hit.get("source", "")
    text = hit.get("text", "")
    sl = src.lower()
    if any(x in sl for x in (".jpg", ".png", ".svg", ".gif", "seite:la2", "blitz-0")):
        return True
    if src.startswith("wiki:") and not is_indexable_content(text, src):
        return True
    if len(text.strip()) < 40:
        return True
    return False


def hit_relevance_score(hit: dict) -> float:
    """Höher = besser (L2-Distanz-kompatibel)."""
    dist = float(hit.get("_distance", 999.0))
    base = 1.0 / (1.0 + dist)
    return base * source_boost(hit.get("source", ""))


def rerank_hits(hits: list[dict], top_k: int) -> list[dict]:
    """Filtert Rauschen und sortiert nach Ähnlichkeit × Quellen-Boost."""
    scored: list[tuple[float, dict]] = []
    seen_text: set[str] = set()

    for hit in hits:
        if is_low_quality_hit(hit):
            continue
        src = hit.get("source", "")
        if is_blocked_source(src):
            continue
        text = (hit.get("text") or "").strip()
        if not text or text[:200] in seen_text:
            continue
        seen_text.add(text[:200])
        scored.append((hit_relevance_score(hit), hit))

    scored.sort(key=lambda x: -x[0])
    return [h for _, h in scored[:top_k]]


def enhance_query(query: str) -> str:
    """Hilft dem Embedding-Modell, IT-relevante Treffer zu finden."""
    q = query.strip()
    lower = q.lower()
    prefixes = ("it ", "tech ", "programmierung:", "informatik:")
    if any(lower.startswith(p) for p in prefixes):
        return q
    return f"IT Informatik Programmierung: {q}"
