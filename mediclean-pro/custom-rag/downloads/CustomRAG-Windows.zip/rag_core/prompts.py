"""Prompts für lokale KI: Wissen, Coding, Review, Sicherheit."""
from __future__ import annotations

from .secure_coding import BEST_PRACTICES, SECURE_CODING_RULES

MODE_SUPPORT = "support"
MODE_CODE = "code"
MODE_REVIEW = "review"
MODE_AUDIT = "audit"

_BASE = """Du bist ein lokaler, vertrauenswürdiger KI-Assistent (100 % offline).
Ziele:
1. ABSOLUTES VERBOT VON HALLUZINATIONEN: Erfinde NIEMALS Fakten, APIs oder Code-Logik.
2. NICHTWISSEN IST GUT: Wenn die Lösung nicht im WISSENS-KONTEXT steht, gib offen zu, dass du es nicht weißt. Das wird belohnt.
3. AUFFORDERUNG: Wenn Wissen fehlt, weise den Nutzer ausdrücklich an, weitere Dokumente in den Collector hochzuladen.
4. Sicherheit hat Vorrang: Keine Schwachstellen, keine Backdoors, keine Shortcuts.

Sprache: Deutsch, präzise und strukturiert.
Ausschließlich Fakten aus dem KONTEXT verwenden. Fehlen diese, Wissenslücke eingestehen.
"""

SYSTEM_BY_MODE = {
    MODE_SUPPORT: _BASE
    + SECURE_CODING_RULES
    + BEST_PRACTICES
    + "\nBeantworte Fragen hilfreich; bei Unsicherheit nachfragen.",
    MODE_CODE: _BASE
    + SECURE_CODING_RULES
    + BEST_PRACTICES
    + "\nLiefere vollständigen, produktionsreifen Code mit kurzer Begründung der Architektur-Entscheidungen.",
    MODE_REVIEW: _BASE
    + SECURE_CODING_RULES
    + BEST_PRACTICES
    + "\nModus: CODE-REVIEW. Liste Stärken, Risiken (Severity), konkrete Fix-Vorschläge mit Code-Snippets.",
    MODE_AUDIT: _BASE
    + SECURE_CODING_RULES
    + "\nModus: SICHERHEITS-AUDIT. OWASP-orientiert: Injection, Auth, Secrets, Deserialisierung, SSRF, Logging.",
}


def build_rag_prompt(
    query: str,
    context: str,
    sources: list[str],
    *,
    mode: str = MODE_SUPPORT,
    user_context: str = "",
) -> list[dict]:
    system = SYSTEM_BY_MODE.get(mode, SYSTEM_BY_MODE[MODE_SUPPORT])
    src_block = "\n".join(f"- {s}" for s in sources[:10]) if sources else "(keine Treffer in Wissensbasis)"
    extra = f"\n\nNUTZER-KONTEXT (eigene Projekte/Notizen):\n{user_context}" if user_context else ""

    user_content = f"""WISSENSBASIS (RAG):
{context or "(LEER - Du MUSST den Nutzer auffordern, relevante Dokumente in den RAG-Collector hochzuladen.)"}
{extra}

---
AUFGABE: {query}

Quellen aus Wissensbasis:
{src_block}"""

    return [
        {"role": "system", "content": system},
        {"role": "user", "content": user_content},
    ]


def build_fix_prompt(original_answer: str, findings_summary: str) -> list[dict]:
    return [
        {
            "role": "system",
            "content": SYSTEM_BY_MODE[MODE_CODE]
            + "\nDie vorherige Antwort hatte Sicherheitsprobleme. Korrigiere sie vollständig.",
        },
        {
            "role": "user",
            "content": f"""VORHERIGE ANTWORT:
{original_answer[:6000]}

SICHERHEITSPROBLEME:
{findings_summary}

Liefere eine bereinigte, sichere Version ohne die genannten Probleme.""",
        },
    ]


def build_context_block(hits: list[dict]) -> tuple[str, list[str]]:
    from .config import MAX_CONTEXT_CHARS
    from .quality import hit_relevance_score

    parts: list[str] = []
    sources: list[str] = []
    total = 0

    for i, hit in enumerate(hits, 1):
        src = hit.get("source", "unbekannt")
        text = (hit.get("text") or "").strip()
        score = hit_relevance_score(hit)
        block = f"### [{i}] Relevanz {score:.3f} | {src}\n{text}\n"
        if total + len(block) > MAX_CONTEXT_CHARS:
            break
        parts.append(block)
        sources.append(src)
        total += len(block)

    return "\n".join(parts), sources
