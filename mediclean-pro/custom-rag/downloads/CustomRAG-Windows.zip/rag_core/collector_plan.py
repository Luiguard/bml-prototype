"""
Optimale Collector-Strategie: Qualität vor Quantität.
Ziel-Tabelle: it_prime (nicht der verrauschte it_knowledge-Index).
"""

# Ordner, die NICHT in die Prime-DB gehören (Rauschen / irrelevant)
PRIME_EXCLUDE_PREFIXES = (
    "gutenberg",
    "books",
    "processed",
    "dumps",
    "wikisource",
    "wiktionary",
    "wikiquote",
    "wikiversity",
)

# Kuratierte Prime-Quellen (Reihenfolge = Priorität)
PRIME_SOURCE_ROOTS = (
    "custom_docs",
    "manpages",
    "stackoverflow",
    "stackexchange",
    "rfcs",
    "mdn-web-docs/files",
    "tldr-pages/pages",
    "arch-wiki",
    "official-docs",
    "owasp",
    "wikipedia",  # nur API-Kollektor (data/wikipedia/*.txt), keine Dumps
    "linux-docs",
)

# Stack Exchange: kleine, hochwertige Sites zuerst (SO zuletzt – 15 GB)
STACKEXCHANGE_QUALITY_ORDER = [
    "security.stackexchange.com",
    "serverfault.com",
    "unix.stackexchange.com",
    "superuser.com",
    "askubuntu.com",
    "softwareengineering.stackexchange.com",
    "stackoverflow.com",
]

# Optional: volle Wikimedia-Dumps (Standard AUS – erzeugt Millionen Junk-Chunks)
WIKIMEDIA_DUMP_OPTIONAL = [
    {"name": "Wikibooks DE", "size": "~50 MB",
     "url": "https://dumps.wikimedia.org/dewikibooks/latest/dewikibooks-latest-pages-articles.xml.bz2",
     "file": "dewikibooks-articles.xml.bz2"},
    {"name": "Wikibooks EN", "size": "~400 MB",
     "url": "https://dumps.wikimedia.org/enwikibooks/latest/enwikibooks-latest-pages-articles.xml.bz2",
     "file": "enwikibooks-articles.xml.bz2"},
    {"name": "Wikiversity DE", "size": "~30 MB",
     "url": "https://dumps.wikimedia.org/dewikiversity/latest/dewikiversity-latest-pages-articles.xml.bz2",
     "file": "dewikiversity-articles.xml.bz2"},
]

WIKIMEDIA_DUMP_LEGACY_FULL = [
    {"name": "Wikipedia DE", "size": "~7.6 GB",
     "url": "https://dumps.wikimedia.org/dewiki/latest/dewiki-latest-pages-articles-multistream.xml.bz2",
     "file": "dewiki-articles.xml.bz2"},
    {"name": "Wikipedia EN", "size": "~23 GB",
     "url": "https://dumps.wikimedia.org/enwiki/latest/enwiki-latest-pages-articles-multistream.xml.bz2",
     "file": "enwiki-articles.xml.bz2"},
]

# Wikipedia-API: strikte IT-Keywords für Link-Expansion
WIKI_LINK_KEYWORDS = (
    "Programmierung", "Software", "Datenbank", "Betriebssystem",
    "Rechnernetz", "Computer", "Algorithmus", "Compiler",
    "JavaScript", "Python", "Linux", "Kubernetes", "Docker",
    "API", "REST", "DevOps", "Sicherheit", "Verschlüsselung",
)

WIKI_MAX_QUEUE = 3_000
WIKI_MAX_DONE = 25_000
SO_MAX_PAGES_PER_TAG = 30  # API: Top-Fragen pro Tag

QUALITY_PIPELINE_PHASES = [
    "Kern-Dokumentation (MDN, TLDR, Git-Docs, OWASP, Arch Wiki)",
    "Referenz (RFCs, Manpages, Linux-Docs)",
    "Stack Exchange (IT-foren, qualitätsgefiltert)",
    "Wikipedia API (nur IT-Seiten, begrenzt)",
    "Stack Overflow API (Top-Tags)",
    "Deine Projekte + Prime-Index (it_prime)",
]
