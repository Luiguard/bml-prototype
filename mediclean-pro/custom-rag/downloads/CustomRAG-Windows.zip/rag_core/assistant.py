"""Einheitlicher Assistent: RAG + Ollama + Sicherheitsprüfung."""
from __future__ import annotations

from typing import Callable

from .ollama import resolve_model
from .prompts import MODE_AUDIT, MODE_CODE, MODE_REVIEW, MODE_SUPPORT, build_fix_prompt
from .retrieval import KnowledgeRetriever
from .secure_coding import audit_code_blocks, format_findings, is_safe_user_intent


class LocalAssistant:
    def __init__(self, retriever: KnowledgeRetriever | None = None):
        self.retriever = retriever or KnowledgeRetriever()

    def parse_mode(self, query: str) -> tuple[str, str]:
        q = query.strip()
        for prefix, mode in (
            ("/code ", MODE_CODE),
            ("/review ", MODE_REVIEW),
            ("/audit ", MODE_AUDIT),
            ("/support ", MODE_SUPPORT),
        ):
            if q.lower().startswith(prefix):
                return q[len(prefix) :].strip(), mode
        if any(w in q.lower() for w in ("sicherheit", "schwachstelle", "owasp", "audit", "backdoor")):
            return q, MODE_AUDIT
        if any(w in q.lower() for w in ("review", "prüfe", "code review", "refactor")):
            return q, MODE_REVIEW
        if any(w in q.lower() for w in ("schreibe", "implementier", "code ", "funktion ", "class ")):
            return q, MODE_CODE
        return q, MODE_SUPPORT

    def answer_text(
        self,
        query: str,
        *,
        mode: str | None = None,
        model: str | None = None,
        user_context: str = "",
        retry_on_unsafe: bool = True,
        on_token: Callable[[str], None] | None = None,
    ) -> dict:
        """Wie answer(), aber ohne print – optional Streaming-Callback pro Token."""
        if not is_safe_user_intent(query):
            return {
                "blocked": True,
                "text": "Anfrage aus Sicherheitsgründen blockiert (destruktiv/unsicher).",
                "hits": [],
            }

        q, mode = (query, mode) if mode else self.parse_mode(query)
        if not self.retriever.ready:
            return {"blocked": False, "text": "Wissensbasis nicht geladen.", "hits": []}

        messages, hits = self.retriever.get_messages_for_ollama(
            q, mode=mode, user_context=user_context
        )
        if not resolve_model(model):
            ctx, _, _ = self.retriever.get_context(q)
            return {"blocked": False, "text": ctx, "hits": hits, "model": None}

        from .ollama import chat_stream

        resolved = resolve_model(model)

        def _stream(msgs: list[dict]) -> str:
            parts: list[str] = []
            for chunk in chat_stream(msgs, model=resolved):
                parts.append(chunk)
                if on_token:
                    on_token(chunk)
            return "".join(parts)

        answer = _stream(messages)
        findings = audit_code_blocks(answer)
        if findings and retry_on_unsafe:
            fix_msgs = build_fix_prompt(answer, format_findings(findings))
            answer = _stream(fix_msgs)
            findings = audit_code_blocks(answer)

        report = format_findings(findings)
        if report:
            answer += "\n" + report

        return {
            "blocked": False,
            "text": answer,
            "hits": hits,
            "findings": findings,
            "model": resolved,
            "mode": mode,
        }

    def answer(
        self,
        query: str,
        *,
        mode: str | None = None,
        user_context: str = "",
        retry_on_unsafe: bool = True,
    ) -> dict:
        def _on_token(chunk: str) -> None:
            print(chunk, end="", flush=True)

        print("\n--- ANTWORT ---\n", end="", flush=True)
        result = self.answer_text(
            query,
            mode=mode,
            user_context=user_context,
            retry_on_unsafe=retry_on_unsafe,
            on_token=_on_token,
        )
        print("\n" + "-" * 40)
        return result
