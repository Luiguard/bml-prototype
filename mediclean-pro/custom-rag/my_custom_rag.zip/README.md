# CustomRAG Integration
        
Um dieses RAG-System auf einer anderen Website zu nutzen:
1. Starte `main.py` (benötigt Python, fastapi, langchain etc.) auf deinem Server.
2. Kopiere die `chroma_db` (die Datenbank) in dasselbe Verzeichnis.
3. Füge folgenden HTML-Code in deine Website ein:

```html
<script>
fetch('http://DEIN_SERVER_IP:8000/chat', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ message: 'Deine Frage' })
}).then(res => res.json()).then(data => console.log(data.response));
</script>
```
