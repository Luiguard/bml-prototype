import os
import tempfile
import shutil
import zipfile
import shutil
from typing import List

from fastapi import FastAPI, UploadFile, File
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain_community.vectorstores import Chroma
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_ollama import OllamaLLM
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_DIR = "./chroma_db"
embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

vectorstore = Chroma(persist_directory=DB_DIR, embedding_function=embeddings)

llm = OllamaLLM(model="llama3.2:latest")
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)

system_prompt = (
    "Du bist eine streng faktische KI-Assistenz für ein RAG-System. Deine absolute oberste Priorität ist die Wahrheit. "
    "Du wirst dafür belohnt, dass du exakt und ausschließlich basierend auf dem bereitgestellten Kontext antwortest. "
    "REGELN:\n"
    "1. Nutze AUSSCHLIESSLICH die folgenden Kontextinformationen, um die Frage zu beantworten.\n"
    "2. Wenn die Informationen zur Beantwortung der Frage im Kontext fehlen, MUSST du sagen: 'Ich weiß es nicht, da diese Information in den bereitgestellten Dokumenten nicht vorhanden ist.'\n"
    "3. Erfinde NIEMALS Fakten, Halluziniere nicht und greife nicht auf externes Wissen zurück.\n"
    "4. Antworte immer auf Deutsch.\n\n"
    "Kontext:\n{context}"
)
prompt = ChatPromptTemplate.from_messages([
    ("system", system_prompt),
    ("human", "{input}"),
])

class ChatRequest(BaseModel):
    message: str

@app.post("/upload")
async def upload_files(files: List[UploadFile] = File(...)):
    docs = []
    
    with tempfile.TemporaryDirectory() as temp_dir:
        for file in files:
            temp_path = os.path.join(temp_dir, file.filename)
            with open(temp_path, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)
            
            # Extract based on file type
            if file.filename.lower().endswith(".pdf"):
                try:
                    loader = PyPDFLoader(temp_path)
                    docs.extend(loader.load())
                except Exception as e:
                    print(f"Error loading PDF {file.filename}: {e}")
            elif file.filename.lower().endswith(".txt") or file.filename.lower().endswith(".md") or file.filename.lower().endswith(".csv"):
                try:
                    loader = TextLoader(temp_path, autodetect_encoding=True)
                    docs.extend(loader.load())
                except Exception as e:
                    print(f"Error loading TXT {file.filename}: {e}")
                
    if docs:
        chunks = text_splitter.split_documents(docs)
        vectorstore.add_documents(chunks)
        # In newer chromadb it auto persists, but we'll leave it as is or omit persist() if it warns
        return {"status": "success", "message": f"{len(files)} Dateien verarbeitet", "chunks": len(chunks)}
    else:
        return {"status": "error", "message": "Keine verarbeitbaren Dokumente gefunden"}

@app.post("/chat")
async def chat(request: ChatRequest):
    retriever = vectorstore.as_retriever(search_kwargs={"k": 4})
    
    def format_docs(docs):
        return "\\n\\n".join(doc.page_content for doc in docs)
        
    rag_chain = (
        {"context": retriever | format_docs, "input": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )
    
    try:
        response = rag_chain.invoke(request.message)
        return {"response": response}
    except Exception as e:
        return {"response": f"Fehler bei der Generierung: {str(e)}"}

@app.get("/export")
async def export_ai():
    export_path = "/tmp/my_custom_rag.zip"
    with zipfile.ZipFile(export_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        if os.path.exists(DB_DIR):
            for root, dirs, files in os.walk(DB_DIR):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, os.path.dirname(DB_DIR))
                    zipf.write(file_path, arcname)
        if os.path.exists("main.py"):
            zipf.write("main.py", "main.py")
        
        readme_content = """# CustomRAG Integration
        
Um dieses RAG-System auf einer anderen Website zu nutzen:
1. Starte `main.py` (benötigt Python, fastapi, langchain etc.) auf deinem Server.
2. Kopiere die `chroma_db` (die Datenbank) in dasselbe Verzeichnis.
3. Füge folgenden HTML-Code in deine Website ein:

```html
<script>
fetch('http://DEIN_SERVER_IP:8000/chat', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ message: 'Deine Frage' })
}).then(res => res.json()).then(data => console.log(data.response));
</script>
```
"""
        zipf.writestr("README.md", readme_content)
        
    return FileResponse(export_path, media_type="application/zip", filename="my_custom_rag.zip")

@app.post("/import")
async def import_ai(file: UploadFile = File(...)):
    global vectorstore
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_zip = os.path.join(temp_dir, "upload.zip")
        with open(temp_zip, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        with zipfile.ZipFile(temp_zip, 'r') as zipf:
            for member in zipf.namelist():
                if member.startswith("chroma_db/"):
                    zipf.extract(member, ".")
                    
    vectorstore = Chroma(persist_directory=DB_DIR, embedding_function=embeddings)
    return {"status": "success", "message": "Wissensdatenbank erfolgreich importiert!"}

app.mount("/", StaticFiles(directory="..", html=True), name="static")

